#!/bin/sh
old=$1
new=$2
OIFS="$IFS"
PWD="$(pwd)"
IFS="
"
#Copy all new grammar changed jar files(*dtpe* jars) to Patch folder
#for file in $( find PATCH -name *.jar -empty -not -path "*/compact/*" -exec basename {} \; | sort | uniq |grep dtpe ); do
for file in $( diff -r -q $old/delivery/compact $new/delivery/compact | grep Only | grep $new | cut -d ' ' -f4 | grep jar); do
      find PATCH -name $file -empty -not -path "*/compact/*" -exec cp $new/delivery/compact/$file {} \;
      done
      IFS="$OIFS"
echo "The Non common Tnexus jars(Grammar jars) that will be part of the patch are: "
find PATCH -iname 'tnexus*.jar' -not -empty -not -path "*/compact/*" -exec basename {} \; | sort | uniq
#echo "The nbr of changed  tnexus Jars is: $nbrNotEmpJar"
