#!/bin/sh
#author: DAHER
OLD=$1
NEW=$2
NAME=$(echo $OLD-$NEW | tr -d ' ') 
echo The patch name: $NAME
mv PATCH/$NEW PATCH/$NAME
mv PATCH/$NAME/delivery/* PATCH/$NAME
rmdir PATCH/$NAME/delivery
cd PATCH
#zip -r $NAME.zip $NAME
cd $NAME 
zip -r $NAME.zip ./*
mv $NAME.zip ../
